const { test, expect } = require('@playwright/test');
const path = require('path');

// This feature (WhatsApp-style "replying to" preview, jump-to-source, and a
// Back button) was lost once already across branch merges/manual reverts —
// these tests exist so that can't happen silently again.
test.describe('Reply Excerpt - jump to source and back', () => {

    test.beforeEach(async ({ page }) => {
        await page.route('**/data.json', route => {
            route.fulfill({
                path: path.join(__dirname, '..', '..', 'data.json')
            });
        });

        await page.goto('/');
        // Book view is the default on a fresh load — switch to continuous
        // view explicitly before waiting on .card, since these tests are
        // continuous-view-specific.
        await page.locator('.view-toggle-btn[data-view="continuous"]').click();
        await expect(page.locator('.card').first()).toBeVisible();
    });

    test('an answer that references its question shows a reply-excerpt', async ({ page }) => {
        // a_001 references q_001 in the fixture.
        const excerpt = page.locator('#a_001 .reply-excerpt.multi-block');
        await expect(excerpt).toBeVisible();
        await expect(excerpt.locator('.excerpt-row')).toHaveCount(1);
    });

    test('a question with no references shows no reply-excerpt', async ({ page }) => {
        await expect(page.locator('#q_001 .reply-excerpt')).toHaveCount(0);
    });

    // Regression test for a real bug: the excerpt used to ignore the
    // language selector entirely and always show both columns.
    test('the excerpt respects the selected language, same as regular blocks', async ({ page }) => {
        await page.locator('#settings-btn').click();
        await page.locator('#lang-trigger').click();
        await page.locator('#lang-chk-en').uncheck(); // leaves only Kannada active
        const excerpt = page.locator('#a_001 .reply-excerpt .excerpt-row').first();
        await expect(excerpt.locator('.col-kn')).toBeVisible();
        await expect(excerpt.locator('.col-en')).toHaveCount(0);
    });

    test('clicking the excerpt block-id scrolls to the source and shows Back to Message', async ({ page }) => {
        const backBtn = page.locator('#back-to-message');
        await expect(backBtn).toBeHidden();

        await page.locator('#a_001 .excerpt-row .block-id').click();

        await expect(backBtn).toBeVisible();
        await expect(backBtn).toContainText('←');
        await expect(page.locator('#q_001_b_1')).toBeInViewport();
    });

    test('clicking Back to Message returns to where the reader jumped from', async ({ page }) => {
        await page.locator('#a_001').scrollIntoViewIfNeeded();
        const scrollBeforeJump = await page.evaluate(() => window.scrollY);

        await page.locator('#a_001 .excerpt-row .block-id').click();

        // The jump is a smooth scroll; on a busy CI runner it can take longer than
        // a fixed 400ms, so wait for the scroll position to change instead.
        await expect.poll(() => page.evaluate(() => window.scrollY), { timeout: 4000 })
            .not.toBe(scrollBeforeJump);

        await page.locator('#back-to-message').click();
        await expect.poll(
            async () => Math.abs((await page.evaluate(() => window.scrollY)) - scrollBeforeJump),
            { timeout: 4000 }
        ).toBeLessThan(30);
    });

    test('clicking the excerpt content expands it, and clicking again collapses it', async ({ page }) => {
        const excerptRow = page.locator('#a_001 .excerpt-row').first();
        const contentWrap = excerptRow.locator('.excerpt-content-wrap');

        await expect(excerptRow).not.toHaveClass(/expanded/);

        await contentWrap.click();
        await expect(excerptRow).toHaveClass(/expanded/);

        await contentWrap.click();
        await expect(excerptRow).not.toHaveClass(/expanded/);
    });
});
