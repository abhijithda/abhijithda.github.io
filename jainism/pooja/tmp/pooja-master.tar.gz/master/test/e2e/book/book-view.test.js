const { test, expect } = require('@playwright/test');
const path = require('path');
const { hasClass, plainPhotoInsert } = require('../test-utils');
const { VIEWS } = require('../media-states');

// Switches into book view and waits for the first spread to actually render
// (initBookView populates cards synchronously, but the first
// renderCurrentSpread() call is deferred via setTimeout). Does NOT assert
// a numbered page — the app now lands on Home first, and book view's own
// default spread is the (unnumbered) cover when the data has one, so
// "some card is visible" is the only thing every caller can rely on.
// Tests that specifically need numbered content check for it themselves.
const openBookView = page => VIEWS.book.open(page);   // shared with the other book/continuous e2e files

test.describe('Book View — using the small controlled fixture', () => {
    test.beforeEach(async ({ page }) => {
        await page.route('**/data.json', route => {
            route.fulfill({
                path: path.join(__dirname, '..', '..', 'data.json')
            });
        });
        // The app now lands on the Home page first, not book view — each
        // test below calls openBookView() itself before relying on its
        // content, so beforeEach only needs to get past the initial goto.
        await page.goto('/');
    });

    test('the view-toggle button switches from continuous to book view', async ({ page }) => {
        await openBookView(page);

        await expect(page.locator('#continuous-container')).toHaveCSS('display', 'none');
        await expect(page.locator('.view-toggle-btn[data-view="book"]')).toHaveClass(/active/);
    });

    // The insert's image and its title must always share one page, at any
    // screen size — if they ever split, the title's box lands outside the
    // card (in the next column) and these bounds checks fail.
    for (const size of [
        { width: 1920, height: 1080 },
        { width: 1280, height: 720 },
        { width: 1024, height: 600 },
        { width: 800, height: 600 },
    ]) {
        test(`the cover's image and both title lines stay on one page at ${size.width}x${size.height}`, async ({ page }) => {
            await page.setViewportSize(size);
            await openBookView(page);

            const card = page.locator('#book-ins_001');
            await expect(card).toBeVisible();
            const cardBox = await card.boundingBox();
            const imgBox = await card.locator('.title-style-image').boundingBox();

            for (const sel of ['.title-style-text-line.lang-kn', '.title-style-text-line.lang-en']) {
                const box = await card.locator(sel).boundingBox();
                expect(box, `${sel} should be rendered`).not.toBeNull();
                // Same column: horizontally inside the card, and vertically
                // below the image and above the card's bottom edge.
                expect(box.x).toBeGreaterThanOrEqual(cardBox.x - 1);
                expect(box.x + box.width).toBeLessThanOrEqual(cardBox.x + cardBox.width + 1);
                expect(box.y).toBeGreaterThanOrEqual(imgBox.y + imgBox.height - 1);
                expect(box.y + box.height).toBeLessThanOrEqual(cardBox.y + cardBox.height + 1);
            }
        });
    }

    test('a standalone photo (insert with no block.content, just a caption) renders as its own centered page, not inline with text', async ({ page }) => {
        // Isolated fixture, not the shared small one — the shared fixture
        // keeps q_001 right on the cover's facing page (spread 0), which
        // every other test in this file relies on; adding a second insert
        // here would push q_001 onto spread 1 and break those.
        await page.route('**/data.json', route => route.fulfill({
            json: [
                { id: 'ins_001', type: 'insert', hideId: true, blocks: [{ id: 'ins_001_b_1', type: 'images' }] },
                plainPhotoInsert('i_001'),
            ],
        }));
        await page.reload();
        await openBookView(page);

        const card = page.locator('#book-i_001');
        await expect(card).toHaveClass(/standalone-image/);
        await expect(card.locator('.book-image')).toBeVisible();
    });

    test('an answer that references its question shows a book-excerpt strip', async ({ page }) => {
        await openBookView(page);

        // a_001 references q_001 in the fixture (same relationship reply-excerpt.test.js checks in continuous view).
        // Preview uses the first active language (kn here) — same fix as
        // applied to the unit test earlier; this e2e test had the same
        // English-text assumption and was never corrected.
        const excerpt = page.locator('#book-a_001_b_1 .book-excerpt');
        await expect(excerpt).toBeVisible();
        await expect(excerpt).toContainText(/ಎಲ್ಲಾ ದೇವರು ಒಂದೇ/);
    });

    test('switching to a single language hides the other language\'s lines in book view', async ({ page }) => {
        await openBookView(page);

        await page.locator('#settings-btn').click();
        await page.locator('#lang-trigger').click();
        // Uncheck Kannada, leaving only English active.
        await page.locator('#lang-chk-kn').uncheck();

        await expect(page.locator('#book-columns .book-lang-line.lang-kn')).toHaveCount(0);
        await expect(page.locator('#book-columns .book-lang-line.lang-en').first()).toBeVisible();
    });

    test('media toggles hide/show the video thumbnail and QR independently in book view', async ({ page }) => {
        await openBookView(page);
        await page.waitForSelector('#book-columns .media-wrap');

        const thumb = page.locator('#book-columns .video-card').first();
        const qr = page.locator('#book-columns .qr-code').first();

        // Default: Videos on, QR on.
        await expect(thumb).toBeVisible();
        await expect(qr).toBeVisible();

        await page.locator('#settings-btn').click();
        await page.locator('#toggle-qrs').uncheck();
        await expect(qr).toBeHidden();
        await expect(thumb).toBeVisible();

        await page.locator('#toggle-qrs').check();
        await expect(qr).toBeVisible();

        await page.locator('#toggle-videos').uncheck();
        await expect(thumb).toBeHidden();
        await expect(qr).toBeVisible();
    });

    test('read tracking works in book view and shares state with the header progress counter', async ({ page }) => {
        await openBookView(page);

        await page.locator('#settings-btn').click();
        await page.locator('#toggle-read-tracking').check();

        const tick = page.locator('#book-q_001_b_1 .read-tick');
        await expect(tick).toBeVisible();
        const progress = page.locator('#read-progress');
        const before = await progress.textContent();

        await tick.click();

        // .read-tick's own base class already contains the substring
        // "read" — toHaveClass(/read/) would pass here regardless of
        // whether the tick were ever actually marked read, so this needs
        // an exact class-token check instead (see test-utils.js).
        expect(await hasClass(tick, 'read')).toBe(true);
        await expect(progress).not.toHaveText(before);
    });

    // Regression coverage for the read-state-shared-across-views design in
    // AI.md: marking a block read in book view must still show as read if
    // the user switches to continuous view (same localStorage key).
    test('a block marked read in book view also shows read in continuous view', async ({ page }) => {
        await openBookView(page);
        await page.locator('#settings-btn').click();
        await page.locator('#toggle-read-tracking').check();
        await page.locator('#book-q_001_b_1 .read-tick').click();

        await page.locator('.view-toggle-btn[data-view="continuous"]').click();
        await expect(page.locator('#continuous-container')).toHaveCSS('display', 'flex');

        await expect(page.locator('#q_001_b_1')).toHaveClass(/read/);
    });
});

test.describe('Book View — navigation, using the live site data', () => {
    // These need a real, multi-page book to exercise Prev/Next/Jump
    // meaningfully, so — unlike the suite above — this one does NOT
    // override data.json with the small test fixture.
    test.beforeEach(async ({ page }) => {
        await page.goto('/');
        await expect(page.locator('.view-toggle-btn[data-view="book"]')).toBeVisible();
        await openBookView(page);
    });

    // The live book opens on its (unnumbered) cover spread by default —
    // like a real book's title page — not page 1. Prev is disabled there
    // same as it always was at the very first spread; it's just that the
    // very first spread is the cover now, not page 1.
    test('starts on the cover (unnumbered), with Prev disabled', async ({ page }) => {
        await expect(page.locator('#book-container')).toHaveClass(/active/);
        await expect(page.locator('#book-spread')).toHaveClass(/cover-spread/);
        await expect(page.locator('#book-page-num-left')).toHaveText('');
        await expect(page.locator('#book-prev')).toBeDisabled();
    });

    test('Next reveals page 1; Prev returns to the cover', async ({ page }) => {
        const nextBtn = page.locator('#book-next');
        test.skip(await nextBtn.isDisabled(), 'content fits on the cover spread alone — nothing to page through');

        await nextBtn.click();
        await expect(page.locator('#book-page-num-left')).toHaveText('1');
        await expect(page.locator('#book-prev')).toBeEnabled();

        await page.locator('#book-prev').click();
        await expect(page.locator('#book-page-num-left')).toHaveText('');
        await expect(page.locator('#book-prev')).toBeDisabled();
    });

    test('the right/left arrow keys page forward and back, like Prev/Next', async ({ page }) => {
        const nextBtn = page.locator('#book-next');
        test.skip(await nextBtn.isDisabled(), 'content fits on the cover spread alone — nothing to page through');

        await page.locator('#book-container').click();
        await page.keyboard.press('ArrowRight');
        await expect(page.locator('#book-page-num-left')).toHaveText('1');

        await page.keyboard.press('ArrowLeft');
        await expect(page.locator('#book-page-num-left')).toHaveText('');
    });

    test('jump-to-page moves straight to the requested spread', async ({ page }) => {
        const spreadInfo = await page.locator('#book-spread-info').textContent(); // "(of N)" — numbered pages only, cover excluded
        const totalPages = parseInt(spreadInfo.replace(/\D/g, ''), 10);
        test.skip(!totalPages || totalPages < 4, 'not enough numbered pages in the live book to jump to page 4');

        await page.locator('#book-jump-input').fill('4');
        await page.locator('#book-jump-go').click();

        await expect(page.locator('#book-page-num-left')).toHaveText('3');
        await expect(page.locator('#book-page-num-right')).toHaveText('4');
    });

    test('typing 0 into jump-to-page returns to the unnumbered cover', async ({ page }) => {
        await page.locator('#book-jump-input').fill('1');
        await page.locator('#book-jump-go').click();
        await expect(page.locator('#book-page-num-left')).toHaveText('1');

        await page.locator('#book-jump-input').fill('0');
        await page.locator('#book-jump-go').click();
        await expect(page.locator('#book-page-num-left')).toHaveText('');
        await expect(page.locator('#book-spread')).toHaveClass(/cover-spread/);
    });

    test('the current page persists across a reload', async ({ page }) => {
        const nextBtn = page.locator('#book-next');
        test.skip(await nextBtn.isDisabled(), 'content fits on the cover spread alone — nothing to page through');

        await nextBtn.click();
        await expect(page.locator('#book-page-num-left')).toHaveText('1');

        await page.reload();
        await expect(page.locator('#book-container')).toHaveClass(/active/);
        await expect(page.locator('#book-page-num-left')).toHaveText('1');
    });
});
